# OBB Trash > 2024-05-08 3:36pm
https://universe.roboflow.com/hua-41ic7/obb-trash-wmdw2

Provided by a Roboflow user
License: CC BY 4.0

